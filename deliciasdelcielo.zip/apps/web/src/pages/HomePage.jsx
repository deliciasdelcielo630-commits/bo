import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  ShoppingBag, Plus, Minus, Trash2, X, MessageCircle, Phone,
  MapPin, Clock, Heart, Star, Instagram, Facebook,
} from 'lucide-react';

const QR_IMAGE =
  'https://horizons-cdn.hostinger.com/7b051d6e-ad24-4124-aa86-f7ada5373c12/9bfa8d49e04522bf0c0dd90edf08c566.jpg';

const PHONES = ['75357891', '68971903'];

const HERO_IMG =
  'https://images.unsplash.com/photo-1683806627608-208157b34241?w=1344&h=768&fit=crop&q=80';

const LOGO_IMG =
  'https://horizons-cdn.hostinger.com/7b051d6e-ad24-4124-aa86-f7ada5373c12/5e37b0cdc4b475379d9ee8dee3196dd6.jpg';

const PRODUCTS = [
  { id: 1, name: 'Torta bañada de chocolate', desc: 'Bizcocho húmedo bañado en chocolate', price: 25, img: 'https://images.hostinger.com/17166c24-c46c-4389-a484-f19501f5d144.png', tag: 'Estrella' },
  { id: 2, name: 'Cookies', desc: 'Galletas caseras con chispas de chocolate', price: 1, img: 'https://images.hostinger.com/c6581007-feaa-4cd3-a013-9a5ee398f438.png' },
  { id: 3, name: 'Dona', desc: 'Dona glaseada con chispas de colores', price: 1, img: 'https://images.hostinger.com/f0284c25-fbd8-4fca-9c46-30cbc3257b5f.png' },
  { id: 4, name: 'Alfajores', desc: 'Rellenos de dulce de leche', price: 1, img: 'https://images.hostinger.com/a7af4621-1ed5-4f3d-8812-944909d848d0.png' },
  { id: 5, name: 'Flan', desc: 'Flan casero con caramelo', price: 3, img: 'https://images.hostinger.com/3fa76159-ec24-40e8-ab36-22f6bbd510a2.png' },
  { id: 6, name: 'Arroz con leche', desc: 'Cremoso con canela', price: 3, img: 'https://images.hostinger.com/dd7e05cc-c262-46e0-946b-25f03a80007e.png' },
  { id: 7, name: 'Payúje con leche', desc: 'Tradicional payúje beniano con leche', price: 5, img: 'https://horizons-cdn.hostinger.com/7b051d6e-ad24-4124-aa86-f7ada5373c12/993d93d3274202010417ae99b07393cd.jpg' },
  { id: 8, name: 'Pasoca de charque con chive', desc: 'Pasoca artesanal de charque con chive, hecha en Trinidad, Beni', price: 5, img: 'https://horizons-cdn.hostinger.com/7b051d6e-ad24-4124-aa86-f7ada5373c12/5e37b0cdc4b475379d9ee8dee3196dd6.jpg' },
  { id: 9, name: 'Cupcakes', desc: 'Cupcakes de chocolate con frosting y sprinkles de colores', price: 1, img: 'https://horizons-cdn.hostinger.com/7b051d6e-ad24-4124-aa86-f7ada5373c12/6e3b1249576cffbbfb10956b5595fa56.jpg' },
];

const money = (n) => `Bs ${n.toFixed(2)}`;

function HomePage() {
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkout, setCheckout] = useState(false);
  const [contactOpen, setContactOpen] = useState(false);

  const add = (p) => {
    setCart((c) => {
      const found = c.find((i) => i.id === p.id);
      if (found) return c.map((i) => (i.id === p.id ? { ...i, qty: i.qty + 1 } : i));
      return [...c, { ...p, qty: 1 }];
    });
    setCartOpen(true);
  };
  const changeQty = (id, d) =>
    setCart((c) =>
      c
        .map((i) => (i.id === id ? { ...i, qty: i.qty + d } : i))
        .filter((i) => i.qty > 0)
    );
  const remove = (id) => setCart((c) => c.filter((i) => i.id !== id));

  const total = useMemo(() => cart.reduce((s, i) => s + i.price * i.qty, 0), [cart]);
  const count = useMemo(() => cart.reduce((s, i) => s + i.qty, 0), [cart]);

  const waMessage = () => {
    let msg = 'Hola Delicias del Cielo! Quiero hacer un pedido:%0A';
    cart.forEach((i) => (msg += `- ${i.qty}x ${i.name} (${money(i.price * i.qty)})%0A`));
    msg += `%0ATotal: ${money(total)}%0AYa realicé el pago por QR.`;
    return msg;
  };

  return (
    <div className="min-h-screen bg-[#FFF9F3] text-[#3B2A24] selection:bg-pink-200">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-[#FFF9F3]/85 border-b border-pink-100">
        <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between">
          <a href="#top" className="flex items-center gap-2">
            <span className="w-10 h-10 rounded-full overflow-hidden ring-2 ring-pink-200 shrink-0 bg-white">
              <img
                src={LOGO_IMG}
                alt="Logo Delicias del Cielo"
                className="w-full h-full object-cover"
                style={{ objectPosition: '52% 68%', transform: 'scale(2.4)' }}
              />
            </span>
            <span className="font-display text-2xl text-pink-500">Delicias del Cielo</span>
          </a>
          <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
            <a href="#menu" className="hover:text-pink-500 transition">Menú</a>
            <a href="#nosotros" className="hover:text-pink-500 transition">Nosotros</a>
            <a href="#ubicacion" className="hover:text-pink-500 transition">Ubicación</a>
          </nav>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setContactOpen(true)}
              className="hidden sm:inline-flex items-center gap-2 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-semibold px-4 py-2 transition active:scale-95"
            >
              <MessageCircle className="w-4 h-4" /> Contáctanos
            </button>
            <button
              onClick={() => setCartOpen(true)}
              className="relative inline-flex items-center gap-2 rounded-full bg-pink-500 hover:bg-pink-600 text-white text-sm font-semibold px-4 py-2 transition active:scale-95"
            >
              <ShoppingBag className="w-4 h-4" />
              <span className="hidden sm:inline">Carrito</span>
              {count > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-amber-400 text-[#3B2A24] text-xs font-bold w-5 h-5 rounded-full grid place-items-center">
                  {count}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section id="top" className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={HERO_IMG} alt="Vitrina de repostería" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#3B2A24]/80 via-[#3B2A24]/45 to-transparent" />
        </div>
        <div className="relative max-w-6xl mx-auto px-5 min-h-[88vh] flex flex-col justify-center">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="max-w-xl text-white"
          >
            <span className="inline-flex items-center gap-2 bg-white/15 backdrop-blur px-3 py-1 rounded-full text-sm mb-5 border border-white/20">
              <Heart className="w-4 h-4 text-pink-300" /> Repostería artesanal · Trinidad, Beni
            </span>
            <h1 className="font-display text-5xl sm:text-6xl md:text-7xl leading-tight mb-5">
              Hecho con <span className="text-pink-300">amor</span>, horneado en casa
            </h1>
            <p className="text-lg text-white/90 mb-8 max-w-md">
              Tortas, cupcakes y postres para endulzar tus momentos especiales. Pide en línea y paga con QR de Banco Unión.
            </p>
            <div className="flex flex-wrap gap-3">
              <a href="#menu" className="rounded-full bg-pink-500 hover:bg-pink-600 px-6 py-3 font-semibold transition active:scale-95">
                Ver el menú
              </a>
              <button
                onClick={() => setContactOpen(true)}
                className="rounded-full bg-white/15 border border-white/30 hover:bg-white/25 px-6 py-3 font-semibold transition active:scale-95 inline-flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4" /> Contáctanos
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Marquee */}
      <div className="bg-pink-500 text-white py-3 overflow-hidden">
        <div className="flex whitespace-nowrap animate-marquee">
          {[...Array(2)].map((_, k) => (
            <span key={k} className="flex">
              {['Tortas personalizadas', 'Envíos en Trinidad', 'Pago por QR', 'Ingredientes frescos', 'Pedidos por WhatsApp'].map((t) => (
                <span key={t} className="mx-6 font-display text-lg flex items-center gap-6">
                  {t} <Star className="w-4 h-4 fill-amber-300 text-amber-300" />
                </span>
              ))}
            </span>
          ))}
        </div>
      </div>

      {/* Menu */}
      <section id="menu" className="max-w-6xl mx-auto px-5 py-20">
        <div className="text-center mb-12">
          <p className="text-pink-500 font-semibold uppercase tracking-widest text-sm">Nuestro menú</p>
          <h2 className="font-display text-4xl md:text-5xl mt-2">Delicias que enamoran</h2>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-7">
          {PRODUCTS.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: (i % 3) * 0.08 }}
              className="group bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl border border-pink-50 transition"
            >
              <div className="relative aspect-square overflow-hidden">
                <img src={p.img} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                {p.tag && (
                  <span className="absolute top-3 left-3 bg-amber-400 text-[#3B2A24] text-xs font-bold px-3 py-1 rounded-full">
                    {p.tag}
                  </span>
                )}
              </div>
              <div className="p-5">
                <h3 className="font-semibold text-lg">{p.name}</h3>
                <p className="text-sm text-[#3B2A24]/60 mt-1 mb-4">{p.desc}</p>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-pink-600 text-lg">{money(p.price)}</span>
                  <button
                    onClick={() => add(p)}
                    className="inline-flex items-center gap-1.5 rounded-full bg-pink-500 hover:bg-pink-600 text-white text-sm font-semibold px-4 py-2 transition active:scale-95"
                  >
                    <Plus className="w-4 h-4" /> Agregar
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Nosotros */}
      <section id="nosotros" className="bg-pink-50/60 py-20">
        <div className="max-w-5xl mx-auto px-5 grid md:grid-cols-2 gap-10 items-center">
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1607690825941-d2c9e62cfd09?w=1024&h=1024&fit=crop&q=80"
              alt="Postres artesanales"
              className="rounded-3xl shadow-lg animate-floaty"
            />
          </div>
          <div>
            <p className="text-pink-500 font-semibold uppercase tracking-widest text-sm">Nosotros</p>
            <h2 className="font-display text-4xl mt-2 mb-4">Dulzura desde Trinidad</h2>
            <p className="text-[#3B2A24]/70 leading-relaxed mb-4">
              En Delicias del Cielo horneamos cada producto de forma artesanal, con ingredientes frescos del Beni y mucho cariño. Cada torta cuenta una historia y cada bocado es un momento de felicidad.
            </p>
            <div className="flex flex-wrap gap-6 pt-2">
              <div><p className="font-display text-3xl text-pink-500">+500</p><p className="text-sm text-[#3B2A24]/60">Pedidos felices</p></div>
              <div><p className="font-display text-3xl text-pink-500">100%</p><p className="text-sm text-[#3B2A24]/60">Artesanal</p></div>
              <div><p className="font-display text-3xl text-pink-500">5★</p><p className="text-sm text-[#3B2A24]/60">Calificación</p></div>
            </div>
          </div>
        </div>
      </section>

      {/* Ubicación */}
      <section id="ubicacion" className="max-w-6xl mx-auto px-5 py-20">
        <div className="grid sm:grid-cols-3 gap-6">
        {[
          { icon: MapPin, title: 'Ubicación', text: 'Trinidad, Beni · Bolivia' },
          { icon: Clock, title: 'Horario', text: 'Lun a Sáb · 08:00 - 20:00' },
          { icon: Phone, title: 'Pedidos', text: '75357891 · 68971903' },
        ].map((c) => (
          <div key={c.title} className="bg-white rounded-3xl p-7 border border-pink-50 shadow-sm text-center">
            <div className="w-12 h-12 rounded-2xl bg-pink-100 text-pink-500 grid place-items-center mx-auto mb-4">
              <c.icon className="w-6 h-6" />
            </div>
            <h3 className="font-semibold mb-1">{c.title}</h3>
            <p className="text-[#3B2A24]/60 text-sm">{c.text}</p>
          </div>
        ))}
        </div>
        <div className="mt-8 text-center">
          <a
            href="https://share.google/pkvk2CSMukrEfF630"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-pink-500 hover:bg-pink-600 text-white font-semibold px-6 py-3 transition active:scale-95"
          >
            <MapPin className="w-5 h-5" />
            Ver ubicación en mapa
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#3B2A24] text-white/80">
        <div className="max-w-6xl mx-auto px-5 py-12 grid md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-9 h-9 rounded-full overflow-hidden ring-2 ring-pink-300/50 shrink-0 bg-white">
                <img
                  src={LOGO_IMG}
                  alt="Logo Delicias del Cielo"
                  className="w-full h-full object-cover"
                  style={{ objectPosition: '52% 68%', transform: 'scale(2.4)' }}
                />
              </span>
              <p className="font-display text-2xl text-pink-300">Delicias del Cielo</p>
            </div>
            <p className="text-sm text-white/60">Repostería artesanal en Trinidad, Beni. Hecho con amor.</p>
          </div>
          <div>
            <p className="font-semibold mb-3">Contacto</p>
            <p className="text-sm">WhatsApp: 75357891</p>
            <p className="text-sm">WhatsApp: 68971903</p>
          </div>
          <div>
            <p className="font-semibold mb-3">Síguenos</p>
            <div className="flex gap-3">
              <a href="#top" className="w-9 h-9 rounded-full bg-white/10 hover:bg-pink-500 grid place-items-center transition"><Instagram className="w-4 h-4" /></a>
              <a href="https://www.facebook.com/profile.php?id=61591844219028" target="_blank" rel="noreferrer" aria-label="Facebook" className="w-9 h-9 rounded-full bg-white/10 hover:bg-pink-500 grid place-items-center transition"><Facebook className="w-4 h-4" /></a>
              <a href="https://www.tiktok.com/@delicias.del.ciel91" target="_blank" rel="noreferrer" aria-label="TikTok" className="w-9 h-9 rounded-full bg-white/10 hover:bg-pink-500 grid place-items-center transition">
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4"><path d="M16.6 5.82a4.28 4.28 0 0 1-1.01-2.82h-3.1v12.7a2.53 2.53 0 1 1-2.53-2.53c.26 0 .51.04.75.11v-3.16a5.66 5.66 0 0 0-.75-.05 5.65 5.65 0 1 0 5.65 5.65V9.01a7.35 7.35 0 0 0 4.3 1.38V7.28a4.28 4.28 0 0 1-3.31-1.46z"/></svg>
              </a>
            </div>
          </div>
        </div>
        <div className="border-t border-white/10 py-5 text-center text-sm text-white/50">
          © {new Date().getFullYear()} Delicias del Cielo. Todos los derechos reservados.
        </div>
      </footer>

      {/* Floating WhatsApp */}
      <button
        onClick={() => setContactOpen(true)}
        aria-label="Contactar por WhatsApp"
        className="fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white grid place-items-center shadow-lg shadow-emerald-500/40 transition active:scale-90"
      >
        <MessageCircle className="w-7 h-7" />
      </button>

      {/* Cart drawer */}
      {cartOpen && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/40" onClick={() => setCartOpen(false)} />
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            transition={{ type: 'tween', duration: 0.3 }}
            className="absolute right-0 top-0 h-full w-full max-w-md bg-[#FFF9F3] flex flex-col shadow-2xl"
          >
            <div className="flex items-center justify-between p-5 border-b border-pink-100">
              <h3 className="font-display text-2xl text-pink-500">Tu carrito</h3>
              <button onClick={() => setCartOpen(false)} className="p-2 hover:bg-pink-100 rounded-full transition"><X className="w-5 h-5" /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {cart.length === 0 ? (
                <div className="text-center text-[#3B2A24]/50 pt-20">
                  <ShoppingBag className="w-12 h-12 mx-auto mb-3 opacity-40" />
                  <p>Tu carrito está vacío</p>
                </div>
              ) : (
                cart.map((i) => (
                  <div key={i.id} className="flex gap-3 bg-white rounded-2xl p-3 border border-pink-50">
                    <img src={i.img} alt={i.name} className="w-16 h-16 rounded-xl object-cover" />
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <p className="font-semibold text-sm">{i.name}</p>
                        <button onClick={() => remove(i.id)} className="text-[#3B2A24]/40 hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
                      </div>
                      <p className="text-pink-600 font-bold text-sm mt-0.5">{money(i.price)}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <button onClick={() => changeQty(i.id, -1)} className="w-7 h-7 rounded-full bg-pink-100 grid place-items-center hover:bg-pink-200"><Minus className="w-3.5 h-3.5" /></button>
                        <span className="w-6 text-center font-semibold text-sm">{i.qty}</span>
                        <button onClick={() => changeQty(i.id, 1)} className="w-7 h-7 rounded-full bg-pink-100 grid place-items-center hover:bg-pink-200"><Plus className="w-3.5 h-3.5" /></button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
            {cart.length > 0 && (
              <div className="p-5 border-t border-pink-100 space-y-3">
                <div className="flex justify-between text-lg font-bold">
                  <span>Total</span><span className="text-pink-600">{money(total)}</span>
                </div>
                <button
                  onClick={() => { setCartOpen(false); setCheckout(true); }}
                  className="w-full rounded-full bg-pink-500 hover:bg-pink-600 text-white font-semibold py-3 transition active:scale-95"
                >
                  Pagar con QR
                </button>
              </div>
            )}
          </motion.aside>
        </div>
      )}

      {/* Checkout / QR modal */}
      {checkout && (
        <div className="fixed inset-0 z-50 grid place-items-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setCheckout(false)} />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative bg-white rounded-3xl w-full max-w-sm p-6 shadow-2xl overflow-y-auto max-h-[92vh]"
          >
            <button onClick={() => setCheckout(false)} className="absolute top-4 right-4 p-2 hover:bg-pink-100 rounded-full transition"><X className="w-5 h-5" /></button>
            <h3 className="font-display text-2xl text-pink-500 text-center mb-1">Pago por QR</h3>
            <p className="text-center text-sm text-[#3B2A24]/60 mb-4">Escanea con tu app de banco</p>
            <div className="rounded-2xl overflow-hidden border border-pink-100 mb-4">
              <img src={QR_IMAGE} alt="Código QR de pago Banco Unión" className="w-full" />
            </div>
            <div className="bg-pink-50 rounded-2xl p-4 text-sm space-y-1 mb-4">
              <div className="flex justify-between"><span className="text-[#3B2A24]/60">Titular</span><span className="font-semibold">Jennifer Dorado Maldonado</span></div>
              <div className="flex justify-between"><span className="text-[#3B2A24]/60">Cuenta</span><span className="font-semibold">75357891</span></div>
              <div className="flex justify-between"><span className="text-[#3B2A24]/60">Banco</span><span className="font-semibold">Banco Unión S.A.</span></div>
              <div className="flex justify-between text-base pt-1"><span className="font-bold">Total a pagar</span><span className="font-bold text-pink-600">{money(total)}</span></div>
            </div>
            <p className="text-xs text-center text-[#3B2A24]/60 mb-3">
              Después de pagar, envíanos tu comprobante por WhatsApp para confirmar tu pedido.
            </p>
            <a
              href={`https://wa.me/591${PHONES[0]}?text=${waMessage()}`}
              target="_blank"
              rel="noreferrer"
              className="w-full inline-flex items-center justify-center gap-2 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white font-semibold py-3 transition active:scale-95"
            >
              <MessageCircle className="w-5 h-5" /> Enviar comprobante
            </a>
          </motion.div>
        </div>
      )}

      {/* Contact modal */}
      {contactOpen && (
        <div className="fixed inset-0 z-50 grid place-items-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setContactOpen(false)} />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative bg-white rounded-3xl w-full max-w-sm p-6 shadow-2xl"
          >
            <button onClick={() => setContactOpen(false)} className="absolute top-4 right-4 p-2 hover:bg-pink-100 rounded-full transition"><X className="w-5 h-5" /></button>
            <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-600 grid place-items-center mx-auto mb-3">
              <MessageCircle className="w-7 h-7" />
            </div>
            <h3 className="font-display text-2xl text-center text-pink-500 mb-1">Contáctanos</h3>
            <p className="text-center text-sm text-[#3B2A24]/60 mb-5">Escríbenos por WhatsApp o llámanos</p>
            <div className="space-y-3">
              {PHONES.map((num) => (
                <div key={num} className="bg-pink-50 rounded-2xl p-3 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-pink-500" />
                    <span className="font-semibold">{num}</span>
                  </div>
                  <div className="flex gap-2">
                    <a href={`https://wa.me/591${num}?text=Hola%20Delicias%20del%20Cielo!%20Quiero%20hacer%20un%20pedido.`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white text-xs font-semibold px-3 py-2 transition active:scale-95">
                      <MessageCircle className="w-3.5 h-3.5" /> WhatsApp
                    </a>
                    <a href={`tel:+591${num}`} className="inline-flex items-center gap-1 rounded-full bg-pink-500 hover:bg-pink-600 text-white text-xs font-semibold px-3 py-2 transition active:scale-95">
                      <Phone className="w-3.5 h-3.5" /> Llamar
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}

export default HomePage;
